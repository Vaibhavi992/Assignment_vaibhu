#include<stdio.h>
int main()
{
	int i;
	for(i=972;i>=897;i--)
	{
		printf("%d\n",i);
	}
	return 0;
}
