#include<stdio.h>
int main()
{
	printf("\t\t-----Your Details-----\n");
	printf("\t\tYour Name :	VAIBHAVI\n");
	printf("\t\tYour Birth date :01/09/1991\n");
	printf("\t\tYour Age :	32\n");
	printf("\t\tAddress : 	B-606, SARTHI PARISHAR,Ahmedabad,Gujarat\n");
	return 0;
}
